package com.lnt.mvc.model;

public class EMI {
	double loanAmount;
	double exShowRoomPrice;
	int tenure;
	String vehicleType;
	double rateOfInterest;

	/*
	 * double roiPerMonth; double emi; double tempData;
	 */
	public EMI(double loanAmount, double exShowRoomPrice, int years, String vehicleType, double rateOfInterest) {
		super();
		this.loanAmount = loanAmount;
		this.exShowRoomPrice = exShowRoomPrice;
		this.tenure = years;
		this.vehicleType = vehicleType;
		this.rateOfInterest = rateOfInterest;
	}

	@Override
	public String toString() {
		return "EMI [loanAmount=" + loanAmount + ", exShowRoomPrice=" + exShowRoomPrice + ", tenure=" + tenure
				+ ", vehicleType=" + vehicleType + ", rateOfInterest=" + rateOfInterest + "]";
	}

	public EMI() {
		super();
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public double getExShowRoomPrice() {
		return exShowRoomPrice;
	}

	public void setExShowRoomPrice(double exShowRoomPrice) {
		this.exShowRoomPrice = exShowRoomPrice;
	}

	public int getTenure() {
		return tenure;
	}

	public void setTenure(int years) {
		this.tenure = years;
	}

	public String getVehicleType() {
		return vehicleType;
	}

	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}

	public double getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
}
