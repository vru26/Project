package com.lnt.mvc.dao;

import com.lnt.mvc.model.EMI;

public class EMIDaoImpl implements IEMIDao {
	private double loanAmount;
	private double exShowRoomPrice;
	private double roiPerMonth;
	private double rateOfInterest;
	private double tempData;
	private double emi;
	private double tenure;
	private double totalInterest;
	private double totalAmountPayable;

	@Override
	public double calculateEMI(EMI e) {
		loanAmount = e.getLoanAmount();
		exShowRoomPrice = e.getExShowRoomPrice();
		rateOfInterest = e.getRateOfInterest();
		tenure = e.getTenure();
		if (loanAmount <= (exShowRoomPrice - (exShowRoomPrice * 0.2))) {
			roiPerMonth = rateOfInterest / 12 / 100;
			tempData = Math.pow((1 + roiPerMonth), tenure);
			emi = loanAmount * roiPerMonth * ((tempData) / (tempData - 1));
			return emi;
		} else {
			return 0;
		}
	}

	@Override
	public double calculateTotalAmtPayable(double emi, int tenure) {
		this.totalAmountPayable = (emi * tenure);
		return (totalAmountPayable);
	}

	@Override
	public double calculateTotalInterest(double loanAmount, double totalAmtPayable) {
		return this.totalInterest = totalAmtPayable - loanAmount;
	}
}