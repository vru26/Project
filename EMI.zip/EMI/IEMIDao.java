package com.lnt.mvc.dao;

import com.lnt.mvc.model.EMI;

public interface IEMIDao {
	public double calculateEMI(EMI e);

	public double calculateTotalAmtPayable(double emi, int tenure);

	public double calculateTotalInterest(double loanAmount, double totalAmtPayable);
}
