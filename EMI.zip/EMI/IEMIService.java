package com.lnt.mvc.service;

import com.lnt.mvc.model.EMI;

public interface IEMIService {
	public double calculateEMI(EMI e);

	public double calculateTotalAmtPayable(double emi, int tenure);

	public double calculateTotalInterest(double loanAmount, double totalAmtPayable);
}
