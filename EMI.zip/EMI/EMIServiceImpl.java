package com.lnt.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.lnt.mvc.dao.IEMIDao;
import com.lnt.mvc.model.EMI;

public class EMIServiceImpl implements IEMIService {

	private IEMIDao emiDao;

	@Autowired
	public void setEmiDao(IEMIDao emiDao) {
		this.emiDao = emiDao;
	}

	@Override
	public double calculateEMI(EMI e) {
		return this.emiDao.calculateEMI(e);
	}

	@Override
	public double calculateTotalAmtPayable(double emi, int tenure) {
		return this.emiDao.calculateTotalAmtPayable(emi, tenure);
	}

	@Override
	public double calculateTotalInterest(double loanAmount, double totalAmtPayable) {
		return this.emiDao.calculateTotalInterest(loanAmount, totalAmtPayable);
	}
}